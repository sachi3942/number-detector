# Number Bulb — Android Overlay App

ස්ක්‍රීන් එකේ ඕනම තැනක තියෙන **number එකක් pointer එකකින් point කරලා**, ඒක ඔයා දාන ඉලක්ක සංඛ්‍යාවට වඩා කුඩාද විශාලද කියලා **floating bulb box** එකකින් (රතු/කොල) පෙන්නන Android app එකක් සදහා වන සම්පූර්ණ project source code එක මෙතන තියෙනවා.

## ⚠️ මුලින්ම කියවන්න

මේ zip එකේ දැන් **GitHub Actions workflow** එකක් (`.github/workflows/build-apk.yml`) දාලා තියෙනවා — ඒකෙන් **GitHub එකේම servers වල** APK එක auto-ව build වෙනවා. ඔයාගේ computer එකේ Android Studio install කරන්න **ඕන නෑ**.

**එක caveat එකක් විතරයි:** GitHub එකේ "Upload files" කියන page එකට **.zip file එකම කෙලින්ම දැම්මොත් ඒක auto-ව extract වෙන්නේ නෑ** — GitHub, zip එකක් upload කරොත් ඒක එකම binary file එකක් විදියට තමයි repo එකට එකතු කරන්නේ (extract කරන්නේ නෑ). ඒ නිසා පහළින් කියන විදියට **zip එක extract කරලා ඇතුලේ තියෙන files/folders සියල්ල** (zip එක නෙවෙයි) upload කරන්න ඕන — එය තත්පර 10ක වැඩක්.

## APK එක GitHub එකෙන්ම auto-build කරගන්නේ මෙහෙමයි

1. [github.com](https://github.com) ගිහින් log වෙන්න.
2. **+** → **New repository** → නමක් දෙන්න (උදා: `number-bulb-app`) → **Public** → **Create repository**.
3. මේ zip එක ඔයාගේ computer එකේදී **extract කරගන්න** (double-click හෝ "Extract All").
4. Repository page එකේ **"uploading an existing file"** link එක ක්ලික් කරන්න.
5. Extract කරගත්ත `NumberBulbApp` folder එක **open කරලා**, ඇතුලේ තියෙන **සියලුම items** (`.github`, `app`, `build.gradle`, `settings.gradle`, `gradle.properties`, `README.md`) එකවර select කරලා (Ctrl+A / Cmd+A) upload page එකට **drag & drop** කරන්න. (Chrome/Edge folder drag-drop එකෙන් folder structure එක auto-ව preserve වෙනවා.)
6. පහළින් **Commit changes** ක්ලික් කරන්න.
7. ඉහළින් **Actions** tab එකට යන්න — "Build APK" කියන workflow එක **auto-ව run වෙනවා** (push එකක් උනාම trigger වෙන්න configure කරලා තියෙන්නේ). මිනිත්තු 3-6ක් විතර යාවි.
8. Green ✅ checkmark එක වැටුනාම, ඒ run එක click කරලා **Artifacts** කියන section එකට යන්න → **number-bulb-app-debug-apk** කියන zip එක download කරන්න → ඇතුලේ `app-debug.apk` file එක තියෙනවා.
9. ඒක ඔයාගේ Android phone එකට copy කරලා install කරගන්න (Settings → Security → "Install unknown apps" allow කරන්න ඕන වෙයි).

### වැරදුනොත්?

Actions run එක ❌ red උනොත්, ඒ run එක click කරලා log එකේ error message එක copy කරලා මට එවන්න — fix කරලා දෙන්නම්. (Common issue: SDK license accept වෙන්නේ නැති එක, dependency version mismatch — දෙකම easy fixes.)

### Android Studio එකෙන් local-ව build කරන්න ඕන නම් (optional alternative)

1. [developer.android.com/studio](https://developer.android.com/studio) වෙතින් Android Studio install කරගන්න.
2. Extract කරගත්ත folder එක Android Studio → **Open** කරන්න.
3. Gradle Sync එක complete වෙනකන් ඉන්න.
4. **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. `app/build/outputs/apk/debug/app-debug.apk` file එක ලැබෙනවා.

## App එක වැඩ කරන විදිය

1. App එක open කරලා **ඉලක්ක සංඛ්‍යාව** type කරන්න (මේ එකම target එකට සාපේක්ෂවයි pointer හැම එකක්ම compare කරන්නේ).
2. "Pointers Screen එකට දාන්න" ඔබන්න.
3. Android permission 2ක් ඉල්ලනවා — **"Display over other apps"** සහ **"Start screen capture / Cast screen"** — දෙකම Allow කරන්න.
4. **පළමු pointer එක** (yellow ring) auto-ව screen එකේ පේනවා. එය ඕනම number එකක් උඩට **drag කරන්න** — ring එකට යටින් තියෙන bulb එක, **ඒ location එකේ number එක වෙනස් වෙන හැම වෙලාවකම live-ව** update වේවි (800ms කට වතාවක් නැවත scan කරනවා).
5. **තව pointer එකක් ඕන නම්**, කෙළවර float වෙන කුඩා control bubble එකේ **"+"** ඔබන්න — අලුත් ring එකක් + **එයටම වෙන වෙනම bulb එකක්** appear වේවි. Pointer 2, 3, 4... එකින් එක drag කරලා වෙනස් number වලට point කරන්න පුලුවන්; **එකක් වෙනස් වුනාට අනිත් pointer වල bulb වලට කිසිම බලපෑමක් වෙන්නේ නෑ** — හැම pointer එකකටම තමන්ගේම independent bulb එකක්.
6. එක් pointer එකක් withdraw කරන්න ඕන නම්, ඒ ring එකේ top-right corner එකේ **✕** එකෙන් ඒක විතරක් අයින් කරගන්න පුලුවන්.
7. **සම්පූර්ණ overlay එකම නවත්තන්න** control bubble එකේ පහළ **✕** (රතු) එකෙන් හෝ app එකේ "Overlay එක නවත්වන්න" button එකෙන්.

## දැනගෙන ඉන්න ඕන දේවල් (Honest caveats)

- **Pointer/bulb එකක්වත් notification එකක්වත් නොපෙනුනොත් — Settings → Apps → Number Bulb → Notifications ගිහින් notifications Allow කරලා තියෙනවද check කරන්න** (permission dialog එකක් app open උනාම එනවා ඕන, ඒක accidentally Deny කරලා තියෙන්න පුලුවන්). Notification permission නැත්නම් service එක background එකේ run වුනත් notification එක පේන්නෙ නෑ.
- Notification panel එකේ "Number Bulb" notification එකේ **real-time status එකක්** පේනවා — "✅ Pointer 1ක් active" කියලා පේනවා නම් pointer එක technical-ව add වෙලා තියෙනවා (screen එකේ visually පේන්නෙ නැත්නම් OEM display restriction එකක් විය හැක). "❌ Error: ..." කියලා පෙන්නුවොත් ඒ error message එකම screenshot කරලා මට එවන්න.

- **Pointer/bulb එකක්වත් නොපෙනුනොත්** — Toast message එකක් screen එකේ පහළින් පේවි ("Pointer එක screen එකේ දාලා ඉවරයි..." හෝ error එකක්). Toast එකක්වත් නොපෙනුනොත් හෝ error message එකක් පෙන්නුවොත් screenshot එකක් එවන්න. Xiaomi/Redmi (MIUI), Oppo, Vivo phone වල "Display over other apps" permission එක Allow කරත්, **වෙනම "Display pop-up windows while running in background"** කියන permission එකක් manually enable කරන්න ඕන — Settings → Apps → Number Bulb → Permissions (හෝ "Other permissions") ඇතුලේ බලන්න.
- **Screen capture permission එක සෑම වතාවකම අලුතෙන් ඉල්ලනවා** — මේක Android app එකකට වෙනස් කරන්න බැරි OS-level security rule එකක්; Google/Samsung screen recorder apps වුනත් මේ විදියටමයි වැඩ කරන්නේ.
- OCR (number හඳුනාගැනීම) ML Kit (Google, on-device, free) පාවිච්චි කරලා — pointer ring එක **stylized fonts, ඉතාම කුඩා text, හෝ අවුල් සහගත background** උඩ තියද්දී නම් හරියටම කියවන්නේ නැති වෙන්න පුලුවන්. Normal size digits සඳහා හොඳින්ම වැඩ කරයි.
- Pointer ring එකේ thin border එකක් තියෙනවා (ලා-transparent yellow tint එකක් සමග) — screen capture එකෙන් ඒ underlying number එකම capture කරගන්න, ඒ අතරේම ring එක ලේසියෙන් pick කරගන්නත් පුලුවන් වෙන්න.
- මේක test කරලා 100%ක්ම verify කරලා නෑ (build කරන්න මගේ environment එකේ tools නැති නිසා) — build/run කරද්දී error එකක් පෙන්නුවොත් screenshot එකක් එවන්න, fix කරලා දෙන්නම්.

## Files

- `app/src/main/java/com/example/numberbulb/MainActivity.kt` — target number එක ඇතුල් කරන screen එක + permissions handle කිරීම
- `app/src/main/java/com/example/numberbulb/OverlayService.kt` — floating pointer, live screen OCR, bulb logic (core)
- `app/src/main/res/layout/overlay_widget.xml` — floating widget UI (ring + bulb badge)
