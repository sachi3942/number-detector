package com.example.numberbulb

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

/**
 * Performs a simulated tap at a given screen coordinate. This is the only
 * reliable, non-root way Android allows an app to tap somewhere on screen
 * on the user's behalf — it requires the user to manually enable it under
 * Settings > Accessibility, since Android treats gesture dispatch as a
 * sensitive capability.
 */
class TapAccessibilityService : AccessibilityService() {

    companion object {
        var instance: TapAccessibilityService? = null
            private set
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        StatusLog.post("TapAccessibilityService connected — auto-tap is now available")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Not needed for gesture dispatch; left empty on purpose.
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        super.onDestroy()
        instance = null
        StatusLog.post("TapAccessibilityService destroyed")
    }

    /** Dispatches a short tap gesture at (x, y) in screen coordinates. */
    fun performTap(x: Float, y: Float) {
        try {
            val path = Path().apply { moveTo(x, y) }
            val stroke = GestureDescription.StrokeDescription(path, 0, 60)
            val gesture = GestureDescription.Builder().addStroke(stroke).build()
            val dispatched = dispatchGesture(gesture, null, null)
            StatusLog.post("Auto-tap dispatched at ($x, $y) -> accepted=$dispatched")
        } catch (e: Exception) {
            StatusLog.post("Auto-tap FAILED: ${e.message}")
        }
    }
}
