package com.example.numberbulb

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent

/**
 * Performs a simulated tap at a given screen coordinate. This is the only
 * reliable, non-root way Android allows an app to tap somewhere on screen
 * on the user's behalf — it requires the user to manually enable it under
 * Settings > Accessibility, since Android treats gesture dispatch as a
 * sensitive capability.
 */
class TapAccessibilityService : AccessibilityService() {

    companion object {
        var instance: TapAccessibilityService? = null
            private set
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        StatusLog.post("TapAccessibilityService connected — auto-tap is now available")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Not needed for gesture dispatch; left empty on purpose.
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        super.onDestroy()
        instance = null
        StatusLog.post("TapAccessibilityService destroyed")
    }

    /** Dispatches a short tap gesture at (x, y) in screen coordinates.
     * Returns true only if the system actually ACCEPTED the gesture for
     * dispatch (not a guarantee it completed, but the best signal available). */
    fun performTap(x: Float, y: Float): Boolean {
        return try {
            val path = Path().apply { moveTo(x, y) }
            val stroke = GestureDescription.StrokeDescription(path, 0, 60)
            val gesture = GestureDescription.Builder().addStroke(stroke).build()
            val accepted = dispatchGesture(gesture, object : GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    StatusLog.post("Auto-tap gesture COMPLETED at ($x, $y)")
                }
                override fun onCancelled(gestureDescription: GestureDescription?) {
                    StatusLog.post("Auto-tap gesture CANCELLED at ($x, $y)")
                }
            }, null)
            StatusLog.post("Auto-tap dispatched at ($x, $y) -> accepted=$accepted")
            accepted
        } catch (e: Exception) {
            StatusLog.post("Auto-tap FAILED: ${e.message}")
            false
        }
    }
}
