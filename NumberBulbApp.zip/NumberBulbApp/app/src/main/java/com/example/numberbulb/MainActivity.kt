package com.example.numberbulb

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var targetInput: EditText
    private lateinit var startButton: Button
    private lateinit var stopButton: Button
    private lateinit var accessibilityButton: Button
    private lateinit var statusPill: TextView
    private lateinit var statusLogText: TextView

    private var pendingTarget: Double = 0.0

    // Keeps the on-screen status log updated live, straight from OverlayService,
    // without relying on a notification or a toast (both can be missed/blocked).
    private val statusLogListener: (String) -> Unit = { text ->
        statusLogText.text = text
    }

    private val overlayPermissionLauncher =
        registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()) {
            StatusLog.post("Overlay permission dialog returned. canDrawOverlays=${Settings.canDrawOverlays(this)}")
            if (Settings.canDrawOverlays(this)) {
                requestScreenCapture()
            } else {
                Toast.makeText(this, "Overlay permission එක දෙන්නම ඕන", Toast.LENGTH_LONG).show()
            }
        }

    private val screenCaptureLauncher =
        registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()) { result ->
            StatusLog.post("Screen capture dialog returned. resultCode=${result.resultCode}")
            if (result.resultCode == Activity.RESULT_OK && result.data != null) {
                val serviceIntent = Intent(this, OverlayService::class.java).apply {
                    putExtra(OverlayService.EXTRA_RESULT_CODE, result.resultCode)
                    putExtra(OverlayService.EXTRA_RESULT_DATA, result.data)
                    putExtra(OverlayService.EXTRA_TARGET, pendingTarget)
                }
                StatusLog.post("Starting OverlayService with target=$pendingTarget")
                try {
                    ContextCompat.startForegroundService(this, serviceIntent)
                    StatusLog.post("startForegroundService() call returned normally")
                } catch (e: Exception) {
                    StatusLog.post("startForegroundService() THREW: ${e.javaClass.simpleName} - ${e.message}")
                }
                startButton.visibility = android.view.View.GONE
                stopButton.visibility = android.view.View.VISIBLE
                statusPill.text = "🟢 Running"
            } else {
                StatusLog.post("Screen capture permission was denied by the user")
                Toast.makeText(this, "Screen capture permission එක දෙන්නම ඕන", Toast.LENGTH_LONG).show()
            }
        }

    private val notificationPermissionLauncher =
        registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.RequestPermission()) { granted ->
            StatusLog.post("Notification permission result: $granted")
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        targetInput = findViewById(R.id.targetInput)
        startButton = findViewById(R.id.startButton)
        stopButton = findViewById(R.id.stopButton)
        accessibilityButton = findViewById(R.id.accessibilityButton)
        statusPill = findViewById(R.id.statusPill)
        statusLogText = findViewById(R.id.statusLogText)

        updateAccessibilityButtonLabel()

        statusLogText.text = StatusLog.currentText()
        StatusLog.post("MainActivity onCreate. Android SDK=${Build.VERSION.SDK_INT}, device=${Build.MANUFACTURER} ${Build.MODEL}")

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) ==
                PackageManager.PERMISSION_GRANTED
            StatusLog.post("POST_NOTIFICATIONS already granted: $granted")
            if (!granted) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        startButton.setOnClickListener {
            val text = targetInput.text.toString()
            val value = text.toDoubleOrNull()
            if (value == null) {
                Toast.makeText(this, "කරුණාකර ඉලක්ක සංඛ්‍යාවක් type කරන්න", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            pendingTarget = value
            StatusLog.clear()
            StatusLog.post("Start button pressed. target=$value")
            requestOverlayPermission()
        }

        stopButton.setOnClickListener {
            StatusLog.post("Stop button pressed")
            stopService(Intent(this, OverlayService::class.java))
            startButton.visibility = android.view.View.VISIBLE
            stopButton.visibility = android.view.View.GONE
            statusPill.text = "⚪ Idle"
        }

        accessibilityButton.setOnClickListener {
            StatusLog.post("Opening Accessibility settings for auto-tap permission")
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
    }

    override fun onResume() {
        super.onResume()
        updateAccessibilityButtonLabel()
    }

    private fun updateAccessibilityButtonLabel() {
        val enabled = TapAccessibilityService.instance != null
        accessibilityButton.text = if (enabled)
            "✅ Auto-tap Permission (Accessibility) - Enabled"
        else
            getString(R.string.enable_accessibility_button)
    }

    override fun onStart() {
        super.onStart()
        StatusLog.addListener(statusLogListener)
        statusLogText.text = StatusLog.currentText()
    }

    override fun onStop() {
        super.onStop()
        StatusLog.removeListener(statusLogListener)
    }

    private fun requestOverlayPermission() {
        StatusLog.post("canDrawOverlays currently: ${Settings.canDrawOverlays(this)}")
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            overlayPermissionLauncher.launch(intent)
        } else {
            requestScreenCapture()
        }
    }

    private fun requestScreenCapture() {
        StatusLog.post("Requesting screen capture permission")
        val projectionManager =
            getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        screenCaptureLauncher.launch(projectionManager.createScreenCaptureIntent())
    }
}
