package com.example.numberbulb

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var targetInput: EditText
    private lateinit var startButton: Button
    private lateinit var stopButton: Button
    private lateinit var statusPill: android.widget.TextView

    private var pendingTarget: Double = 0.0

    private val overlayPermissionLauncher =
        registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()) {
            if (Settings.canDrawOverlays(this)) {
                requestScreenCapture()
            } else {
                Toast.makeText(this, "Overlay permission එක දෙන්නම ඕන", Toast.LENGTH_LONG).show()
            }
        }

    private val screenCaptureLauncher =
        registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK && result.data != null) {
                val serviceIntent = Intent(this, OverlayService::class.java).apply {
                    putExtra(OverlayService.EXTRA_RESULT_CODE, result.resultCode)
                    putExtra(OverlayService.EXTRA_RESULT_DATA, result.data)
                    putExtra(OverlayService.EXTRA_TARGET, pendingTarget)
                }
                ContextCompat.startForegroundService(this, serviceIntent)
                startButton.visibility = android.view.View.GONE
                stopButton.visibility = android.view.View.VISIBLE
                statusPill.text = "🟢 Running"
            } else {
                Toast.makeText(this, "Screen capture permission එක දෙන්නම ඕන", Toast.LENGTH_LONG).show()
            }
        }

    private val notificationPermissionLauncher =
        registerForActivityResult(androidx.activity.result.contract.ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        targetInput = findViewById(R.id.targetInput)
        startButton = findViewById(R.id.startButton)
        stopButton = findViewById(R.id.stopButton)
        statusPill = findViewById(R.id.statusPill)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        startButton.setOnClickListener {
            val text = targetInput.text.toString()
            val value = text.toDoubleOrNull()
            if (value == null) {
                Toast.makeText(this, "කරුණාකර ඉලක්ක සංඛ්‍යාවක් type කරන්න", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            pendingTarget = value
            requestOverlayPermission()
        }

        stopButton.setOnClickListener {
            stopService(Intent(this, OverlayService::class.java))
            startButton.visibility = android.view.View.VISIBLE
            stopButton.visibility = android.view.View.GONE
            statusPill.text = "⚪ Idle"
        }
    }

    private fun requestOverlayPermission() {
        if (!Settings.canDrawOverlays(this)) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            overlayPermissionLauncher.launch(intent)
        } else {
            requestScreenCapture()
        }
    }

    private fun requestScreenCapture() {
        val projectionManager =
            getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        screenCaptureLauncher.launch(projectionManager.createScreenCaptureIntent())
    }
}
