package com.example.numberbulb

import android.os.Handler
import android.os.Looper

/**
 * A tiny in-memory, same-process status log.
 * OverlayService posts a line at every meaningful step; MainActivity
 * subscribes and shows the rolling log live in a status box, so failures
 * are visible immediately instead of depending on a notification or a
 * toast that can be missed or suppressed by the OS.
 */
object StatusLog {
    private val lines = mutableListOf<String>()
    private const val MAX_LINES = 40
    private val listeners = mutableListOf<(String) -> Unit>()
    private val mainHandler = Handler(Looper.getMainLooper())

    @Synchronized
    fun post(line: String) {
        val timestamped = "${System.currentTimeMillis() % 100000}: $line"
        lines.add(timestamped)
        if (lines.size > MAX_LINES) lines.removeAt(0)
        val snapshot = currentText()
        mainHandler.post {
            listeners.forEach { it(snapshot) }
        }
    }

    @Synchronized
    fun currentText(): String =
        if (lines.isEmpty()) "තවම log entries නෑ" else lines.joinToString("\n")

    fun addListener(listener: (String) -> Unit) {
        listeners.add(listener)
    }

    fun removeListener(listener: (String) -> Unit) {
        listeners.remove(listener)
    }

    @Synchronized
    fun clear() {
        lines.clear()
    }
}
