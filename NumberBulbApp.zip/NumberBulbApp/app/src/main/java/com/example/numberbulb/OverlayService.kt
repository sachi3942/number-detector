package com.example.numberbulb

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.res.Resources
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class OverlayService : Service() {

    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        const val EXTRA_TARGET = "target_value"
        const val CHANNEL_ID = "number_bulb_channel"
        const val NOTIF_ID = 1
        const val SCAN_INTERVAL_MS = 800L
    }

    // One entry per independently placed pointer + its own bulb
    private data class PointerWidget(
        val id: Int,
        val view: View,
        val params: WindowManager.LayoutParams,
        val crosshair: View,
        val bulbDot: View,
        val statusText: TextView
    )

    private lateinit var windowManager: WindowManager

    private lateinit var controlView: View
    private lateinit var controlParams: WindowManager.LayoutParams

    private val pointers = mutableListOf<PointerWidget>()
    private var nextPointerId = 0

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    private var screenWidth = 0
    private var screenHeight = 0
    private var screenDensity = 0

    private var targetValue: Double = 0.0

    private val mainHandler = Handler(Looper.getMainLooper())
    private val textRecognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    private var initialX = 0
    private var initialY = 0
    private var initialTouchX = 0f
    private var initialTouchY = 0f

    private val scanRunnable = object : Runnable {
        override fun run() {
            scanAllPointers()
            mainHandler.postDelayed(this, SCAN_INTERVAL_MS)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, -1) ?: -1
        val resultData: Intent? = intent?.getParcelableExtra(EXTRA_RESULT_DATA)
        targetValue = intent?.getDoubleExtra(EXTRA_TARGET, 0.0) ?: 0.0

        startForeground(NOTIF_ID, buildNotification())

        if (resultCode != -1 && resultData != null) {
            setupMediaProjection(resultCode, resultData)
            setupControlBubble()
            addPointerWidget() // start with one pointer; user can add more with "+"
            mainHandler.post(scanRunnable)
        } else {
            stopSelf()
        }

        return START_NOT_STICKY
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Number Bulb Overlay",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Number Bulb ක්‍රියාත්මකයි")
            .setContentText("\"+\" එකෙන් pointer අලුතින් දාන්න, එකක් එකක් independent-ව drag කරන්න")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setOngoing(true)
            .build()
    }

    private fun setupMediaProjection(resultCode: Int, data: Intent) {
        val projectionManager =
            getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = projectionManager.getMediaProjection(resultCode, data)
        mediaProjection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                stopSelf()
            }
        }, mainHandler)

        val metrics = Resources.getSystem().displayMetrics
        screenWidth = metrics.widthPixels
        screenHeight = metrics.heightPixels
        screenDensity = metrics.densityDpi

        imageReader = ImageReader.newInstance(
            screenWidth, screenHeight, PixelFormat.RGBA_8888, 2
        )

        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "NumberBulbCapture",
            screenWidth, screenHeight, screenDensity,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface, null, mainHandler
        )
    }

    // ---------- Control bubble (+ / stop) ----------

    private fun setupControlBubble() {
        val inflater = getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        controlView = inflater.inflate(R.layout.control_bubble, null)

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            WindowManager.LayoutParams.TYPE_PHONE

        controlParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        controlParams.gravity = Gravity.TOP or Gravity.START
        controlParams.x = 20
        controlParams.y = screenHeight / 4

        windowManager.addView(controlView, controlParams)
        makeDraggable(controlView, controlParams)

        controlView.findViewById<View>(R.id.addPointerBtn).setOnClickListener {
            addPointerWidget()
        }
        controlView.findViewById<View>(R.id.stopAllBtn).setOnClickListener {
            stopSelf()
        }
    }

    // ---------- Pointer widgets (each independent, own bulb) ----------

    private fun addPointerWidget() {
        val inflater = getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val view = inflater.inflate(R.layout.overlay_widget, null)

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START

        // Cascade new pointers so they don't stack exactly on top of each other
        val cascade = (pointers.size % 6) * 60
        params.x = screenWidth / 3 + cascade
        params.y = screenHeight / 4 + cascade

        windowManager.addView(view, params)
        makeDraggable(view.findViewById(R.id.crosshair), params, view)

        val id = nextPointerId++
        val crosshair = view.findViewById<View>(R.id.crosshair)
        val bulbDot = view.findViewById<View>(R.id.bulbDot)
        val statusText = view.findViewById<TextView>(R.id.statusText)
        val closeButton = view.findViewById<View>(R.id.closeButton)

        val widget = PointerWidget(id, view, params, crosshair, bulbDot, statusText)
        pointers.add(widget)

        closeButton.setOnClickListener {
            removePointerWidget(widget)
        }
    }

    private fun removePointerWidget(widget: PointerWidget) {
        try {
            windowManager.removeView(widget.view)
        } catch (e: Exception) {
            // already removed
        }
        pointers.remove(widget)
    }

    /** Drag handling. If [rootView] is provided, that whole view moves even though
     * the touch listener sits on the (smaller) [dragHandle]. */
    private fun makeDraggable(
        dragHandle: View,
        params: WindowManager.LayoutParams,
        rootView: View = dragHandle
    ) {
        dragHandle.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initialX + (event.rawX - initialTouchX).toInt()
                    params.y = initialY + (event.rawY - initialTouchY).toInt()
                    windowManager.updateViewLayout(rootView, params)
                    true
                }
                else -> false
            }
        }
    }

    // ---------- Scanning: one screen capture per cycle, shared by all pointers ----------

    private fun scanAllPointers() {
        if (pointers.isEmpty()) return
        val reader = imageReader ?: return
        val image: Image = try {
            reader.acquireLatestImage() ?: return
        } catch (e: Exception) {
            return
        }

        val bitmap: Bitmap
        try {
            bitmap = imageToBitmap(image)
        } finally {
            image.close()
        }

        // Snapshot the list to avoid concurrent modification if user adds/removes mid-scan
        val currentPointers = pointers.toList()
        for (widget in currentPointers) {
            val location = IntArray(2)
            widget.crosshair.getLocationOnScreen(location)
            val left = location[0].coerceIn(0, bitmap.width - 1)
            val top = location[1].coerceIn(0, bitmap.height - 1)
            val size = widget.crosshair.width.coerceAtLeast(10)
            val right = (left + size).coerceAtMost(bitmap.width)
            val bottom = (top + size).coerceAtMost(bitmap.height)

            if (right <= left || bottom <= top) continue

            val cropped = Bitmap.createBitmap(bitmap, left, top, right - left, bottom - top)
            val inputImage = InputImage.fromBitmap(cropped, 0)

            textRecognizer.process(inputImage)
                .addOnSuccessListener { visionText ->
                    val number = extractNumber(visionText.text)
                    updateBulb(widget, number)
                }
                .addOnFailureListener {
                    updateBulb(widget, null)
                }
        }
    }

    private fun imageToBitmap(image: Image): Bitmap {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * image.width

        val bitmap = Bitmap.createBitmap(
            image.width + rowPadding / pixelStride,
            image.height,
            Bitmap.Config.ARGB_8888
        )
        bitmap.copyPixelsFromBuffer(buffer)
        return bitmap
    }

    private fun extractNumber(text: String): Double? {
        val regex = Regex("-?\\d+(\\.\\d+)?")
        val match = regex.find(text) ?: return null
        return match.value.toDoubleOrNull()
    }

    /** Updates only this specific pointer's own bulb — never affects other pointers. */
    private fun updateBulb(widget: PointerWidget, detected: Double?) {
        mainHandler.post {
            // Guard: pointer may have been removed while OCR was running
            if (!pointers.contains(widget)) return@post

            if (detected == null) {
                widget.bulbDot.background.setTint(resources.getColor(R.color.bulb_off, theme))
                widget.statusText.text = "..."
                return@post
            }

            when {
                detected < targetValue -> {
                    widget.bulbDot.background.setTint(resources.getColor(R.color.bulb_red, theme))
                    widget.statusText.text = "${detected} < ${targetValue}"
                }
                detected > targetValue -> {
                    widget.bulbDot.background.setTint(resources.getColor(R.color.bulb_green, theme))
                    widget.statusText.text = "${detected} > ${targetValue}"
                }
                else -> {
                    widget.bulbDot.background.setTint(resources.getColor(R.color.bulb_off, theme))
                    widget.statusText.text = "${detected} = ${targetValue}"
                }
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        mainHandler.removeCallbacks(scanRunnable)

        for (widget in pointers.toList()) {
            try {
                windowManager.removeView(widget.view)
            } catch (e: Exception) { /* already removed */
            }
        }
        pointers.clear()

        if (::controlView.isInitialized) {
            try {
                windowManager.removeView(controlView)
            } catch (e: Exception) { /* already removed */
            }
        }

        virtualDisplay?.release()
        imageReader?.close()
        mediaProjection?.stop()
    }
}
