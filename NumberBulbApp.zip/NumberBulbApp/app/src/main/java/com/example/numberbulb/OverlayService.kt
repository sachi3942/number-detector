package com.example.numberbulb

import android.app.AlertDialog
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Resources
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.TextView
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class OverlayService : Service() {

    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        const val EXTRA_TARGET = "target_value"
        const val CHANNEL_ID = "number_bulb_channel"
        const val NOTIF_ID = 1
        const val SCAN_INTERVAL_MS = 800L
        const val FLASH_DURATION_MS = 1000L
        const val DEFAULT_POINTER_SIZE_DP = 90
    }

    // One entry per independently placed pointer + its own bulb.
    // Each pointer now carries its OWN target value, its OWN size, and its own
    // pending "turn the flash back off" callback so pointers never affect each other.
    private class PointerWidget(
        val id: Int,
        val view: View,
        val params: WindowManager.LayoutParams,
        val crosshair: View,
        val bulbDot: View,
        val statusText: TextView,
        var target: Double,
        var sizeDp: Int
    ) {
        var pendingResetRunnable: Runnable? = null
        // True while a flash pulse is currently lit — blocks new pulses from
        // starting until the current one finishes, so it reads as one clean
        // "on for a second, then off" pulse instead of continuous blinking.
        var isFlashing: Boolean = false
        // The last number that actually triggered a flash. A new flash only
        // starts when a freshly detected number is DIFFERENT from this — not
        // just because the previous pulse's timer ran out.
        var lastFlashedValue: Double? = null
        // Auto-tap: when enabled, a real tap is dispatched (via TapAccessibilityService)
        // at tapMarkerView's location — but only after this pointer's bulb has
        // flashed the chosen color autoTapThreshold times. Each pointer counts
        // and taps completely independently of every other pointer.
        var autoTapEnabled: Boolean = false
        var autoTapColorFilter: String = "green" // "green", "red", or "both"
        var autoTapThreshold: Int = 1
        var autoTapCurrentCount: Int = 0
        var tapMarkerView: View? = null
        var tapMarkerParams: WindowManager.LayoutParams? = null
        // Live diagnostics, shown in a separate floating stats box.
        var greenFlashCount: Int = 0
        var redFlashCount: Int = 0
        var totalTapsPerformed: Int = 0
        var statsView: View? = null
        var statsParams: WindowManager.LayoutParams? = null
        var statsBodyText: TextView? = null
    }

    private lateinit var windowManager: WindowManager

    private lateinit var controlView: View
    private lateinit var controlParams: WindowManager.LayoutParams

    private val pointers = mutableListOf<PointerWidget>()
    private var nextPointerId = 0

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    private var screenWidth = 0
    private var screenHeight = 0
    private var screenDensity = 0

    private var targetValue: Double = 0.0

    private val mainHandler = Handler(Looper.getMainLooper())
    private val textRecognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    private var initialX = 0
    private var initialY = 0
    private var initialTouchX = 0f
    private var initialTouchY = 0f

    private var scanCount = 0

    private val scanRunnable = object : Runnable {
        override fun run() {
            scanAllPointers()
            mainHandler.postDelayed(this, SCAN_INTERVAL_MS)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        StatusLog.post("OverlayService.onCreate()")
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        StatusLog.post("OverlayService.onStartCommand() entered")
        try {
            val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, Int.MIN_VALUE) ?: Int.MIN_VALUE
            val resultData: Intent? = intent?.getParcelableExtra(EXTRA_RESULT_DATA)
            targetValue = intent?.getDoubleExtra(EXTRA_TARGET, 0.0) ?: 0.0
            StatusLog.post("resultCode=$resultCode, resultData=${if (resultData != null) "present" else "NULL"}, target=$targetValue")

            // Android 14+ requires the foreground service TYPE to be passed explicitly
            // to startForeground() for mediaProjection services, not just declared in
            // the manifest — omitting this causes an immediate silent crash on some
            // devices (no notification, no toast) before any of our own code runs.
            StatusLog.post("Calling ServiceCompat.startForeground()...")
            ServiceCompat.startForeground(
                this,
                NOTIF_ID,
                buildNotification("ආරම්භ වෙමින්..."),
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q)
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                else
                    0
            )
            StatusLog.post("startForeground() succeeded")

            if (!android.provider.Settings.canDrawOverlays(this)) {
                StatusLog.post("❌ canDrawOverlays() = false. Stopping.")
                updateNotification("❌ Overlay permission නෑ")
                stopSelf()
                return START_NOT_STICKY
            }
            StatusLog.post("canDrawOverlays() = true, continuing")

            if (resultCode == android.app.Activity.RESULT_OK && resultData != null) {
                try {
                    StatusLog.post("Calling setupMediaProjection()...")
                    setupMediaProjection(resultCode, resultData)
                    StatusLog.post("setupMediaProjection() OK. screen=${screenWidth}x${screenHeight} density=$screenDensity")

                    StatusLog.post("Calling setupControlBubble()...")
                    setupControlBubble()
                    StatusLog.post("setupControlBubble() OK")

                    StatusLog.post("Calling addPointerWidget()...")
                    addPointerWidget()
                    StatusLog.post("addPointerWidget() OK. total pointers=${pointers.size}")

                    mainHandler.post(scanRunnable)
                    StatusLog.post("✅ Scan loop started. Everything set up successfully.")
                    updateNotification("✅ Pointer 1ක් active")
                } catch (e: Exception) {
                    StatusLog.post("❌ EXCEPTION during setup: ${e.javaClass.simpleName} - ${e.message}")
                    StatusLog.post("   stack: ${e.stackTrace.take(3).joinToString(" | ")}")
                    updateNotification("❌ Error: ${e.message}")
                }
            } else {
                StatusLog.post("❌ resultCode/resultData invalid, stopping self")
                stopSelf()
            }
        } catch (e: Throwable) {
            StatusLog.post("❌ TOP-LEVEL EXCEPTION in onStartCommand: ${e.javaClass.simpleName} - ${e.message}")
            StatusLog.post("   stack: ${e.stackTrace.take(3).joinToString(" | ")}")
            stopSelf()
        }

        return START_NOT_STICKY
    }

    private fun updateNotification(statusText: String) {
        try {
            val manager = getSystemService(NotificationManager::class.java)
            manager.notify(NOTIF_ID, buildNotification(statusText))
        } catch (e: Exception) {
            StatusLog.post("updateNotification failed: ${e.message}")
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Number Bulb Overlay",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(statusText: String): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Number Bulb")
            .setContentText(statusText)
            .setStyle(NotificationCompat.BigTextStyle().bigText(statusText))
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setOngoing(true)
            .build()
    }

    private fun setupMediaProjection(resultCode: Int, data: Intent) {
        val projectionManager =
            getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = projectionManager.getMediaProjection(resultCode, data)
        StatusLog.post("  getMediaProjection() -> ${if (mediaProjection != null) "OK" else "NULL"}")

        mediaProjection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                StatusLog.post("MediaProjection.Callback.onStop() fired - system revoked projection")
                stopSelf()
            }
        }, mainHandler)

        val metrics = Resources.getSystem().displayMetrics
        screenWidth = metrics.widthPixels
        screenHeight = metrics.heightPixels
        screenDensity = metrics.densityDpi
        StatusLog.post("  displayMetrics: ${screenWidth}x${screenHeight} @ ${screenDensity}dpi")

        imageReader = ImageReader.newInstance(
            screenWidth, screenHeight, PixelFormat.RGBA_8888, 2
        )
        StatusLog.post("  ImageReader created")

        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "NumberBulbCapture",
            screenWidth, screenHeight, screenDensity,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface, null, mainHandler
        )
        StatusLog.post("  createVirtualDisplay() -> ${if (virtualDisplay != null) "OK" else "NULL"}")
    }

    // ---------- Control bubble (+ / stop) ----------

    private fun setupControlBubble() {
        val inflater = getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        controlView = inflater.inflate(R.layout.control_bubble, null)
        StatusLog.post("  control_bubble inflated")

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            WindowManager.LayoutParams.TYPE_PHONE

        controlParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        controlParams.gravity = Gravity.TOP or Gravity.START
        controlParams.x = 20
        controlParams.y = screenHeight / 4

        windowManager.addView(controlView, controlParams)
        StatusLog.post("  control bubble windowManager.addView() succeeded, x=${controlParams.x} y=${controlParams.y}")
        makeDraggable(controlView, controlParams)

        controlView.findViewById<View>(R.id.addPointerBtn).setOnClickListener {
            StatusLog.post("+ button tapped, asking for this pointer's target number")
            promptForTargetAndAddPointer()
        }
        controlView.findViewById<View>(R.id.stopAllBtn).setOnClickListener {
            StatusLog.post("Stop-all bubble tapped")
            stopSelf()
        }
    }

    /** Shows a small floating dialog asking for the new pointer's own target number,
     * size, and auto-tap settings, then adds the pointer once confirmed. Works from
     * a Service by giving the dialog's window an overlay type. */
    private fun promptForTargetAndAddPointer() {
        val form = buildPointerForm(
            targetValue, DEFAULT_POINTER_SIZE_DP,
            autoTapChecked = false, colorFilter = "green", threshold = 1
        )

        val dialog = AlertDialog.Builder(this)
            .setTitle("නව Pointer")
            .setView(form.container)
            .setPositiveButton("එකතු කරන්න") { _, _ ->
                val value = form.targetInput.text.toString().toDoubleOrNull() ?: targetValue
                val size = form.sizeInput.text.toString().toIntOrNull()?.coerceIn(40, 300) ?: DEFAULT_POINTER_SIZE_DP
                val autoTap = form.autoTapCheckbox.isChecked
                val colorFilter = form.selectedColorFilter()
                val threshold = form.thresholdInput.text.toString().toIntOrNull()?.coerceAtLeast(1) ?: 1
                StatusLog.post("New pointer: target=$value size=${size}dp autoTap=$autoTap color=$colorFilter threshold=$threshold")
                addPointerWidget(value, size, autoTap, colorFilter, threshold)
            }
            .setNegativeButton("අවලංගු කරන්න", null)
            .create()

        showAsOverlayDialog(dialog)
    }

    /** Long-press on an existing pointer's ring opens this to change its target
     * number, size, and auto-tap settings after it's already been placed. */
    private fun promptEditPointer(widget: PointerWidget) {
        val form = buildPointerForm(
            widget.target, widget.sizeDp,
            autoTapChecked = widget.autoTapEnabled,
            colorFilter = widget.autoTapColorFilter,
            threshold = widget.autoTapThreshold
        )

        val dialog = AlertDialog.Builder(this)
            .setTitle("Pointer #${widget.id} සකසන්න")
            .setView(form.container)
            .setPositiveButton("Update") { _, _ ->
                val value = form.targetInput.text.toString().toDoubleOrNull() ?: widget.target
                val size = form.sizeInput.text.toString().toIntOrNull()?.coerceIn(40, 300) ?: widget.sizeDp
                val autoTap = form.autoTapCheckbox.isChecked
                val colorFilter = form.selectedColorFilter()
                val threshold = form.thresholdInput.text.toString().toIntOrNull()?.coerceAtLeast(1) ?: 1
                StatusLog.post("Pointer #${widget.id} updated: target=$value size=${size}dp autoTap=$autoTap color=$colorFilter threshold=$threshold")
                widget.target = value
                widget.sizeDp = size
                widget.lastFlashedValue = null // force a fresh flash under the new target
                applyCrosshairSize(widget)
                widget.statusText.text = "ඉලක්කය: $value — number එකක් උඩට drag කරන්න"

                if (autoTap && !widget.autoTapEnabled) {
                    addTapMarker(widget)
                } else if (!autoTap && widget.autoTapEnabled) {
                    removeTapMarker(widget)
                }
                widget.autoTapEnabled = autoTap
                widget.autoTapColorFilter = colorFilter
                widget.autoTapThreshold = threshold
                widget.autoTapCurrentCount = 0 // settings changed — start counting fresh
            }
            .setNegativeButton("Cancel", null)
            .create()

        showAsOverlayDialog(dialog)
    }

    private class PointerForm(
        val container: View,
        val targetInput: EditText,
        val sizeInput: EditText,
        val autoTapCheckbox: android.widget.CheckBox,
        val greenRadio: android.widget.RadioButton,
        val redRadio: android.widget.RadioButton,
        val bothRadio: android.widget.RadioButton,
        val thresholdInput: EditText
    ) {
        fun selectedColorFilter(): String = when {
            greenRadio.isChecked -> "green"
            redRadio.isChecked -> "red"
            else -> "both"
        }
    }

    /** Builds a small labeled form: target number, size(dp), auto-tap toggle,
     * which color counts toward a tap, and how many flashes are needed. */
    private fun buildPointerForm(
        currentTarget: Double,
        currentSizeDp: Int,
        autoTapChecked: Boolean,
        colorFilter: String,
        threshold: Int
    ): PointerForm {
        val density = resources.displayMetrics.density
        val pad = (16 * density).toInt()

        val container = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(pad, pad / 2, pad, 0)
        }

        val targetLabel = TextView(this).apply { text = "ඉලක්ක සංඛ්‍යාව" }
        val targetInput = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or
                InputType.TYPE_NUMBER_FLAG_DECIMAL or
                InputType.TYPE_NUMBER_FLAG_SIGNED
            setText(currentTarget.toString())
        }

        val sizeLabel = TextView(this).apply {
            text = "Pointer size (dp) — 40 - 300"
            setPadding(0, pad, 0, 0)
        }
        val sizeInput = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(currentSizeDp.toString())
        }

        val autoTapCheckbox = android.widget.CheckBox(this).apply {
            text = "Auto-tap enable කරන්න (Accessibility permission ඕන)"
            isChecked = autoTapChecked
            setPadding(0, pad, 0, 0)
        }

        val colorLabel = TextView(this).apply {
            text = "කුමන පාට count කරන්නද?"
            setPadding(0, pad, 0, 0)
        }
        val colorRadioGroup = android.widget.RadioGroup(this).apply {
            orientation = android.widget.RadioGroup.HORIZONTAL
        }
        val greenRadio = android.widget.RadioButton(this).apply {
            id = View.generateViewId()
            text = "🟢 කොල"
        }
        val redRadio = android.widget.RadioButton(this).apply {
            id = View.generateViewId()
            text = "🔴 රතු"
        }
        val bothRadio = android.widget.RadioButton(this).apply {
            id = View.generateViewId()
            text = "දෙකම"
        }
        colorRadioGroup.addView(greenRadio)
        colorRadioGroup.addView(redRadio)
        colorRadioGroup.addView(bothRadio)
        when (colorFilter) {
            "red" -> redRadio.isChecked = true
            "both" -> bothRadio.isChecked = true
            else -> greenRadio.isChecked = true
        }

        val thresholdLabel = TextView(this).apply {
            text = "කී පාරක් පත්තු වුනාම tap කරන්නද?"
            setPadding(0, pad, 0, 0)
        }
        val thresholdInput = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(threshold.toString())
        }

        container.addView(targetLabel)
        container.addView(targetInput)
        container.addView(sizeLabel)
        container.addView(sizeInput)
        container.addView(autoTapCheckbox)
        container.addView(colorLabel)
        container.addView(colorRadioGroup)
        container.addView(thresholdLabel)
        container.addView(thresholdInput)

        return PointerForm(container, targetInput, sizeInput, autoTapCheckbox, greenRadio, redRadio, bothRadio, thresholdInput)
    }

    private fun showAsOverlayDialog(dialog: AlertDialog) {
        dialog.window?.setType(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                WindowManager.LayoutParams.TYPE_PHONE
        )
        dialog.show()
    }

    /** Adds a small draggable "tap marker" the user positions over whatever they
     * want tapped when this pointer's bulb turns green. */
    private fun addTapMarker(widget: PointerWidget) {
        if (widget.tapMarkerView != null) return // already has one

        val inflater = getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val markerView = inflater.inflate(R.layout.tap_marker, null)

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            WindowManager.LayoutParams.TYPE_PHONE

        val markerParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        markerParams.gravity = Gravity.TOP or Gravity.START
        // Start it a little to the side of the pointer so it's easy to find & drag away
        markerParams.x = widget.params.x + 100
        markerParams.y = widget.params.y + 100

        windowManager.addView(markerView, markerParams)
        makeDraggable(markerView, markerParams)
        StatusLog.post("Tap marker added for pointer #${widget.id} at x=${markerParams.x} y=${markerParams.y} — drag it onto the tap target")

        widget.tapMarkerView = markerView
        widget.tapMarkerParams = markerParams

        // A separate floating box showing live tap/count stats for THIS pointer,
        // plus whether the Accessibility service is actually connected — the
        // fastest way to see why a tap isn't happening without digging into logs.
        val statsView = inflater.inflate(R.layout.tap_stats, null)
        val statsParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        statsParams.gravity = Gravity.TOP or Gravity.START
        statsParams.x = markerParams.x
        statsParams.y = markerParams.y + 70

        windowManager.addView(statsView, statsParams)
        makeDraggable(statsView, statsParams)

        widget.statsView = statsView
        widget.statsParams = statsParams
        widget.statsBodyText = statsView.findViewById(R.id.statsBody)
        updateStatsDisplay(widget)
    }

    /** Refreshes a pointer's floating stats box: green/red flash counts, current
     * progress toward the next tap, total successful taps, and whether the
     * Accessibility service is actually connected right now. */
    private fun updateStatsDisplay(widget: PointerWidget) {
        val text = widget.statsBodyText ?: return
        val accessOn = TapAccessibilityService.instance != null
        text.text = "🟢 green: ${widget.greenFlashCount}  🔴 red: ${widget.redFlashCount}\n" +
            "count: ${widget.autoTapCurrentCount}/${widget.autoTapThreshold} (${widget.autoTapColorFilter})\n" +
            "taps done: ${widget.totalTapsPerformed}\n" +
            "Accessibility: ${if (accessOn) "✅ connected" else "❌ NOT connected"}"
    }

    private fun removeTapMarker(widget: PointerWidget) {
        widget.tapMarkerView?.let {
            try {
                windowManager.removeView(it)
            } catch (e: Exception) { /* already removed */
            }
        }
        widget.tapMarkerView = null
        widget.tapMarkerParams = null

        widget.statsView?.let {
            try {
                windowManager.removeView(it)
            } catch (e: Exception) { /* already removed */
            }
        }
        widget.statsView = null
        widget.statsParams = null
        widget.statsBodyText = null

        StatusLog.post("Tap marker + stats box removed for pointer #${widget.id}")
    }

    /** Dispatches a real tap at the pointer's tap-marker location, if auto-tap is
     * enabled and the accessibility service is turned on. */
    private fun performAutoTap(widget: PointerWidget) {
        if (!widget.autoTapEnabled) return
        val marker = widget.tapMarkerView
        val markerParams = widget.tapMarkerParams
        if (marker == null || markerParams == null) {
            StatusLog.post("Pointer #${widget.id}: auto-tap enabled but no tap marker placed yet")
            updateStatsDisplay(widget)
            return
        }
        val service = TapAccessibilityService.instance
        if (service == null) {
            StatusLog.post("❌ Pointer #${widget.id}: Accessibility service not enabled — auto-tap skipped. Settings > Accessibility > Number Bulb වලින් enable කරන්න")
            updateStatsDisplay(widget)
            return
        }
        val location = IntArray(2)
        marker.getLocationOnScreen(location)
        val x = (location[0] + marker.width / 2).toFloat()
        val y = (location[1] + marker.height / 2).toFloat()

        // CRITICAL: not just the marker but ALSO the pointer ring, its badge,
        // the stats box, and the control bubble are all separate floating
        // windows that commonly end up stacked close together on screen. ANY
        // of them sitting at this exact coordinate would silently swallow the
        // synthetic touch (dispatchGesture still reports accepted=true even
        // when it lands on our own UI instead of the real app underneath).
        // So make EVERY one of our overlay windows click-through for the
        // moment of the tap, then restore them all right after.
        //
        // updateViewLayout() only QUEUES the flag change with the system —
        // it isn't applied instantly. Dispatching the gesture in the same
        // instant can race ahead of that change actually taking effect, so
        // the tap still gets swallowed by our own (briefly still-touchable)
        // window. A short delay before the actual dispatch gives the system
        // time to apply the flag first.
        setAllOverlaysTouchable(false)

        mainHandler.postDelayed({
            StatusLog.post("Pointer #${widget.id}: dispatching auto-tap at ($x, $y)")
            val accepted = service.performTap(x, y)
            if (accepted) {
                widget.totalTapsPerformed++
            }
            updateStatsDisplay(widget)

            mainHandler.postDelayed({
                setAllOverlaysTouchable(true)
            }, 400)
        }, 120)
    }

    /** Toggles FLAG_NOT_TOUCHABLE on an overlay window so it can be made
     * momentarily "click-through" (touches pass to whatever is beneath it)
     * without hiding it or losing its position. */
    private fun setWindowTouchable(view: View, params: WindowManager.LayoutParams, touchable: Boolean) {
        params.flags = if (touchable) {
            params.flags and WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE.inv()
        } else {
            params.flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        }
        try {
            windowManager.updateViewLayout(view, params)
        } catch (e: Exception) {
            StatusLog.post("setWindowTouchable failed: ${e.message}")
        }
    }

    /** Makes every one of our floating windows (control bubble, every pointer
     * ring, every tap marker, every stats box) click-through at once, or
     * restores them all — used to guarantee a synthetic auto-tap actually
     * reaches the real app underneath instead of hitting our own overlay UI. */
    private fun setAllOverlaysTouchable(touchable: Boolean) {
        if (::controlView.isInitialized) {
            setWindowTouchable(controlView, controlParams, touchable)
        }
        for (p in pointers.toList()) {
            setWindowTouchable(p.view, p.params, touchable)
            p.tapMarkerView?.let { v -> p.tapMarkerParams?.let { setWindowTouchable(v, it, touchable) } }
            p.statsView?.let { v -> p.statsParams?.let { setWindowTouchable(v, it, touchable) } }
        }
    }

    /** Applies a pointer's current sizeDp to its actual views: resizes the ring
     * and shifts the badge below it so they never overlap regardless of size. */
    private fun applyCrosshairSize(widget: PointerWidget) {
        val density = resources.displayMetrics.density
        val sizePx = (widget.sizeDp * density).toInt()
        val gapPx = (4 * density).toInt()

        val crosshairParams = widget.crosshair.layoutParams
        crosshairParams.width = sizePx
        crosshairParams.height = sizePx
        widget.crosshair.layoutParams = crosshairParams

        val badge = widget.view.findViewById<View>(R.id.badge)
        val badgeParams = badge.layoutParams as android.widget.FrameLayout.LayoutParams
        badgeParams.topMargin = sizePx + gapPx
        badge.layoutParams = badgeParams

        widget.view.requestLayout()
        try {
            windowManager.updateViewLayout(widget.view, widget.params)
        } catch (e: Exception) {
            StatusLog.post("applyCrosshairSize: updateViewLayout failed: ${e.message}")
        }
    }

    // ---------- Pointer widgets (each independent, own bulb) ----------

    private fun addPointerWidget(
        target: Double = targetValue,
        sizeDp: Int = DEFAULT_POINTER_SIZE_DP,
        autoTap: Boolean = false,
        autoTapColorFilter: String = "green",
        autoTapThreshold: Int = 1
    ) {
        val inflater = getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        val view = inflater.inflate(R.layout.overlay_widget, null)
        StatusLog.post("  overlay_widget inflated (target=$target, size=${sizeDp}dp, autoTap=$autoTap)")

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else
            WindowManager.LayoutParams.TYPE_PHONE

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.TOP or Gravity.START

        // Cascade new pointers so they don't stack exactly on top of each other
        val cascade = (pointers.size % 6) * 60
        params.x = screenWidth / 3 + cascade
        params.y = screenHeight / 4 + cascade
        StatusLog.post("  pointer target position x=${params.x} y=${params.y} (screen=${screenWidth}x${screenHeight})")

        windowManager.addView(view, params)
        StatusLog.post("  pointer windowManager.addView() succeeded")

        val id = nextPointerId++
        val crosshair = view.findViewById<View>(R.id.crosshair)
        val bulbDot = view.findViewById<View>(R.id.bulbDot)
        val statusText = view.findViewById<TextView>(R.id.statusText)
        val closeButton = view.findViewById<View>(R.id.closeButton)
        statusText.text = "ඉලක්කය: $target — number එකක් උඩට drag කරන්න"

        val widget = PointerWidget(id, view, params, crosshair, bulbDot, statusText, target, sizeDp)
        pointers.add(widget)
        applyCrosshairSize(widget)
        StatusLog.post("  pointer #$id registered with target=$target size=${sizeDp}dp, total=${pointers.size}")

        if (autoTap) {
            widget.autoTapEnabled = true
            widget.autoTapColorFilter = autoTapColorFilter
            widget.autoTapThreshold = autoTapThreshold
            addTapMarker(widget)
        }

        makeDraggable(crosshair, params, view, onLongPress = {
            StatusLog.post("Pointer #$id long-pressed, opening edit dialog")
            promptEditPointer(widget)
        })

        closeButton.setOnClickListener {
            StatusLog.post("Pointer #$id close button tapped")
            removePointerWidget(widget)
        }
    }

    private fun removePointerWidget(widget: PointerWidget) {
        widget.pendingResetRunnable?.let { mainHandler.removeCallbacks(it) }
        removeTapMarker(widget)
        try {
            windowManager.removeView(widget.view)
        } catch (e: Exception) {
            StatusLog.post("removePointerWidget: view already removed")
        }
        pointers.remove(widget)
    }

    /** Drag handling. If [rootView] is provided, that whole view moves even though
     * the touch listener sits on the (smaller) [dragHandle]. [onLongPress], if given,
     * fires when the user presses and holds without moving — implemented manually
     * here because a custom OnTouchListener that consumes events (needed for
     * dragging) otherwise blocks Android's built-in long-click detection. */
    private fun makeDraggable(
        dragHandle: View,
        params: WindowManager.LayoutParams,
        rootView: View = dragHandle,
        onLongPress: (() -> Unit)? = null
    ) {
        val longPressTimeoutMs = android.view.ViewConfiguration.getLongPressTimeout().toLong()
        val touchSlop = android.view.ViewConfiguration.get(this).scaledTouchSlop
        var downRawX = 0f
        var downRawY = 0f
        var moved = false
        val longPressRunnable = Runnable {
            if (!moved) onLongPress?.invoke()
        }

        dragHandle.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    downRawX = event.rawX
                    downRawY = event.rawY
                    moved = false
                    if (onLongPress != null) {
                        mainHandler.postDelayed(longPressRunnable, longPressTimeoutMs)
                    }
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = event.rawX - downRawX
                    val dy = event.rawY - downRawY
                    if (!moved && (kotlin.math.abs(dx) > touchSlop || kotlin.math.abs(dy) > touchSlop)) {
                        moved = true
                        mainHandler.removeCallbacks(longPressRunnable)
                    }
                    if (moved) {
                        params.x = initialX + (event.rawX - initialTouchX).toInt()
                        params.y = initialY + (event.rawY - initialTouchY).toInt()
                        windowManager.updateViewLayout(rootView, params)
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    mainHandler.removeCallbacks(longPressRunnable)
                    true
                }
                else -> false
            }
        }
    }

    // ---------- Scanning: one screen capture per cycle, shared by all pointers ----------

    private fun scanAllPointers() {
        if (pointers.isEmpty()) return
        val reader = imageReader ?: return
        val image: Image = try {
            reader.acquireLatestImage() ?: run {
                if (scanCount == 0) StatusLog.post("scanAllPointers: acquireLatestImage() returned null (no frame ready yet)")
                return
            }
        } catch (e: Exception) {
            StatusLog.post("scanAllPointers: acquireLatestImage() threw ${e.message}")
            return
        }

        scanCount++
        if (scanCount == 1) StatusLog.post("First screen frame captured successfully (${image.width}x${image.height})")

        val bitmap: Bitmap
        try {
            bitmap = imageToBitmap(image)
        } catch (e: Exception) {
            StatusLog.post("imageToBitmap failed: ${e.message}")
            image.close()
            return
        } finally {
            image.close()
        }

        // Snapshot the list to avoid concurrent modification if user adds/removes mid-scan
        val currentPointers = pointers.toList()
        for (widget in currentPointers) {
            val location = IntArray(2)
            widget.crosshair.getLocationOnScreen(location)
            val left = location[0].coerceIn(0, bitmap.width - 1)
            val top = location[1].coerceIn(0, bitmap.height - 1)
            val size = widget.crosshair.width.coerceAtLeast(10)
            val right = (left + size).coerceAtMost(bitmap.width)
            val bottom = (top + size).coerceAtMost(bitmap.height)

            if (right <= left || bottom <= top) continue

            val cropped = Bitmap.createBitmap(bitmap, left, top, right - left, bottom - top)
            val inputImage = InputImage.fromBitmap(cropped, 0)

            textRecognizer.process(inputImage)
                .addOnSuccessListener { visionText ->
                    val number = extractNumber(visionText.text)
                    updateBulb(widget, number)
                }
                .addOnFailureListener { e ->
                    StatusLog.post("OCR failed for pointer #${widget.id}: ${e.message}")
                    updateBulb(widget, null)
                }
        }
    }

    private fun imageToBitmap(image: Image): Bitmap {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * image.width

        val bitmap = Bitmap.createBitmap(
            image.width + rowPadding / pixelStride,
            image.height,
            Bitmap.Config.ARGB_8888
        )
        bitmap.copyPixelsFromBuffer(buffer)
        return bitmap
    }

    private fun extractNumber(text: String): Double? {
        val regex = Regex("-?\\d+(\\.\\d+)?")
        val match = regex.find(text) ?: return null
        return match.value.toDoubleOrNull()
    }

    /** Updates only this specific pointer's own bulb — never affects other pointers.
     * The bulb flashes ONLY when the detected number actually CHANGES to a
     * different value from the last one that triggered a flash — not on a timer,
     * and not just because the previous pulse happened to finish. A repeated
     * reading of the same number does nothing further; only a genuine change
     * (e.g. the number under the pointer becomes a different number) starts a
     * fresh pulse: on for FLASH_DURATION_MS, then off. */
    private fun updateBulb(widget: PointerWidget, detected: Double?) {
        mainHandler.post {
            // Guard: pointer may have been removed while OCR was running
            if (!pointers.contains(widget)) return@post

            if (detected == null) {
                if (!widget.isFlashing) {
                    widget.statusText.text = "ඉලක්කය: ${widget.target} — number එකක් හම්බුනේ නෑ"
                }
                return@post
            }

            val flashColorRes: Int
            val comparisonText: String
            when {
                detected < widget.target -> {
                    flashColorRes = R.color.bulb_red
                    comparisonText = "$detected < ${widget.target}"
                }
                detected > widget.target -> {
                    flashColorRes = R.color.bulb_green
                    comparisonText = "$detected > ${widget.target}"
                }
                else -> {
                    flashColorRes = R.color.bulb_off
                    comparisonText = "$detected = ${widget.target}"
                }
            }

            // The status text can update on every scan regardless of pulse state,
            // so it always shows the latest reading even between flashes.
            widget.statusText.text = comparisonText

            // Don't interrupt a pulse that's already lit.
            if (widget.isFlashing) return@post

            // The core fix: only start a new pulse if this reading is actually
            // DIFFERENT from the number that triggered the last pulse. A repeat
            // of the same number does nothing — no flash.
            if (widget.lastFlashedValue != null && widget.lastFlashedValue == detected) {
                return@post
            }

            widget.lastFlashedValue = detected
            widget.isFlashing = true
            widget.bulbDot.background.setTint(resources.getColor(flashColorRes, theme))

            // Auto-tap counting: only counts flashes of the color the user chose
            // (green / red / both). Tap only fires once the count reaches the
            // user's threshold, then the counter resets and starts again.
            if (widget.autoTapEnabled) {
                val flashedColorName = when (flashColorRes) {
                    R.color.bulb_green -> "green"
                    R.color.bulb_red -> "red"
                    else -> null
                }
                if (flashedColorName == "green") widget.greenFlashCount++
                if (flashedColorName == "red") widget.redFlashCount++

                val countsTowardTap = flashedColorName != null &&
                    (widget.autoTapColorFilter == "both" || widget.autoTapColorFilter == flashedColorName)

                if (countsTowardTap) {
                    widget.autoTapCurrentCount++
                    StatusLog.post("Pointer #${widget.id}: $flashedColorName flash count ${widget.autoTapCurrentCount}/${widget.autoTapThreshold}")
                    if (widget.autoTapCurrentCount >= widget.autoTapThreshold) {
                        performAutoTap(widget)
                        widget.autoTapCurrentCount = 0
                    }
                } else if (flashedColorName != null && widget.autoTapColorFilter != "both" && widget.autoTapCurrentCount > 0) {
                    // The OPPOSITE color interrupted an in-progress count — start over.
                    StatusLog.post("Pointer #${widget.id}: $flashedColorName interrupted the count (was ${widget.autoTapCurrentCount}/${widget.autoTapThreshold}) — resetting to 0")
                    widget.autoTapCurrentCount = 0
                }
                updateStatsDisplay(widget)
            }

            val resetRunnable = Runnable {
                widget.bulbDot.background.setTint(resources.getColor(R.color.bulb_off, theme))
                widget.isFlashing = false
                widget.pendingResetRunnable = null
            }
            widget.pendingResetRunnable = resetRunnable
            mainHandler.postDelayed(resetRunnable, FLASH_DURATION_MS)
        }
    }

    override fun onDestroy() {
        StatusLog.post("OverlayService.onDestroy()")
        super.onDestroy()
        mainHandler.removeCallbacks(scanRunnable)

        for (widget in pointers.toList()) {
            widget.pendingResetRunnable?.let { mainHandler.removeCallbacks(it) }
            widget.tapMarkerView?.let {
                try { windowManager.removeView(it) } catch (e: Exception) { /* already removed */ }
            }
            widget.statsView?.let {
                try { windowManager.removeView(it) } catch (e: Exception) { /* already removed */ }
            }
            try {
                windowManager.removeView(widget.view)
            } catch (e: Exception) { /* already removed */
            }
        }
        pointers.clear()

        if (::controlView.isInitialized) {
            try {
                windowManager.removeView(controlView)
            } catch (e: Exception) { /* already removed */
            }
        }

        virtualDisplay?.release()
        imageReader?.close()
        mediaProjection?.stop()
    }
}
